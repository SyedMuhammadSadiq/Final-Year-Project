<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
<?php include('include/header.php');?>
<?php include('include/sidemenu.php');?>
  
	 					<div class="main">
								<table class="table table-bordered"> 
									<thead class="thead-dark">
										  
										<tr>
		
											<th>#</th>
											<th>User Name</th>
											<th>Email </th>
											<th>Contact No</th>
											<th>Shipping Address</th>
 
											
										</tr>
									</thead>
									<tbody>
						
										<tr>
											<td>1</td>
											<td>Moid Ahmed</td>
											<td>moidahmed0@gmail.com</td>
											<td>03363057355</td>
											<td>gulshan iqbal , isphanni road karachi</td>
											 
										</tr>
										<tr>
											<td>2</td>
											<td>Sultan abbas</td>
											<td>sultanabbas@gmail.com</td>
											<td>03362345555</td>
											<td>gulshan iqbal , isphanni road karachi</td>
											 
										</tr>
										<tr>
											<td>3</td>
											<td>Sadiq</td>
											<td>smsadiq@gmail.com</td>
											<td>03364352353</td>
											<td>gulshan iqbal , isphanni road karachi</td>
											 
										</tr>
										 

									</tbody>
								</table>
				</div>
<?php include('include/footer.php');?>

</body>
</html>