<!DOCTYPE html>
<html lang="en">
<head>
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
	<?php include('include/header.php');?>
<?php include('include/sidemenu.php');?>
  <div class="main">

								<table class="table table-bordered"> 
									<thead class="thead-dark">
										  
										<tr>
		
											<th>#</th>
											<th> Name</th>
											<th>Email </th>
											<th>Contact No</th>
											<th>Shipping Address</th>
											<th>Products </th>
											<th>Quantity </th>
											<th>Total Amount </th>
											<th>Action</th>
											
											
										</tr>
									</thead>
									<tbody>
						
										<tr>
											<td>1</td>
											<td>Moid ahmed</td>
											<td>moidahmed0@gmail.com</td>
											<td>03363057355</td>
											<td>gulshan iqbal , isphani road , karachi</td>
											<td>brown rice, bread , peanut biscuit</td>
											<td>3</td>
											<td>345</td>
											<td><a href="">response </a></td>
										</tr>
										<tr>
											<td>2</td>
											<td>sultan abbas</td>
											<td>sultanabbas@gmail.com</td>
											<td>03363464578</td>
											<td>gulshan iqbal , isphani road , karachi</td>
											<td>brown rice, bread</td>
											<td>2</td>
											<td>300</td>
											<td><a href="">response </a></td>
										</tr>
										<tr>
											<td>3</td>
											<td>sadiq</td>
											<td>smsadiq@gmail.com</td>
											<td>03365468590</td>
											<td>gulshan iqbal , isphani road , karachi</td>
											<td>bread , peanut biscuit</td>
											<td>2</td>
											<td>210</td>
											<td><a href="">response </a></td>
										</tr>
									
										 

									</tbody>
								</table>
		</div>
<?php include('include/footer.php');?>

 
</body>
</html>