<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
 
</head>
<body>



<div class="span3">
					<div class="sidebar">


<ul class="widget widget-menu unstyled">
							<li>
								<a class="collapsed" data-toggle="collapse" href="#togglePages">
									<i class="menu-icon icon-cog"></i>
									<i class="icon-chevron-down pull-right"></i><i class="icon-chevron-up pull-right"></i>
									Order Management
								</a>
								<ul id="togglePages" class="collapse unstyled">
									<li>
										<a href="todays-orders.php">
											<i class="icon-tasks"></i>
											Today's Orders
 
											<b class="label orange pull-right"></b>
											 
										</a>
									</li>
									<li>
										<a href="pending-orders.php">
											<i class="icon-tasks"></i>
											Pending Orders


										</a>
									</li>
									<li>
										<a href="pending-orders.php">
											<i class="icon-tasks"></i>
											Delivered Orders


										</a>
									</li>
								</ul>
							</li>
							
							<li>
								<a href="manage-users.php">
									<i class="menu-icon icon-group"></i>
									Manage users
								</a>
							</li>
						</ul>


						<ul class="widget widget-menu unstyled">
                                <li><a href="category.php"><i class="menu-icon icon-tasks"></i> Create Category </a></li>
                                <li><a href="subcategory.php"><i class="menu-icon icon-tasks"></i>Sub Category </a></li>
                                <li><a href="insert-product.php"><i class="menu-icon icon-paste"></i>Insert Product </a></li>
                                <li><a href="manage-products.php"><i class="menu-icon icon-table"></i>Manage Products </a></li>
                        
                            </ul><!--/.widget-nav-->

						<ul class="widget widget-menu unstyled">
							<li><a href="user-logs.php"><i class="menu-icon icon-tasks"></i>Registered Users </a></li>
							
							
						</ul>

					</div><!--/.sidebar-->
				</div><!--/.span3-->


				<div class="sidenav" >
  
  <li>
<a class="collapsed" data-toggle="collapse" href="#togglePages"  style=" word-spacing: 5px">
	Order Management
	  <label class="glyphicon glyphicon-chevron-down"></label> </a>  

	 
</a>
<ul id="togglePages" class="collapse ">
									
 
    <li><a href="Delivered-orders.php">Todays Orders </a></li>
    <li><a href="Delivered-orders.php">Pending Orders</a></li>
    <li><a href="Delivered-orders.php">Delivered Orders</a></li>

 
</ul></li>
                <hr>
  <a href="manage-users.php">Manage Users</a><hr>	
  <a href="create-category.php">Create Category</a><hr>
  <a href="subcategory.php">Sub Category</a><hr>
  <a href="insert-product.php">Insert Products</a><hr>
  <a href="manage-products.php">Manage Products</a><hr>
  <a href="registered-users.php">Registered User</a> 
   
</div>







</body>
</html>



