

<!DOCTYPE html>
<html lang="en">
<head>
  <title ></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  

  <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> -->
<!--
  
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css"/>
 
 <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.min.js"></script> 
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>  

-->


<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap.min.css"/>
 
<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap.min.js"></script>


<style>
body {
  font-family: "Lato", sans-serif;
}





</style>
		 
</head>
<body>

<nav class="navbar navbar-inverse" style="background-color: #43870c">
  <div class="container-fluid" style="  height: 50px; ">
    <div class="navbar-header"  >
       <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar"  >
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
       </button>
 
      <a class="navbar-brand " href="index.php" style="color: #f1f1f1; margin-right: 1020px; ">Comfort Mart | Admin </a> <br><br>
    </div>
   
   
   <!--<div class="collapse navbar-collapse" id="myNavbar " class="span6 pull-right">  -->
        	
       <ul class="nav navbar-nav  navbar-right"  > 
      	<div class="dropdown"><br>
    <button class="btn dropdown-toggle" type="button" data-toggle="dropdown"   >Admin
   </button> 
    <ul class="dropdown-menu dropdown-menu-right" style="position: absolute;" >
    	        <li><a href="change_password.php"><span class="glyphicon glyphicon-lock" ></span>Change Password</a></li>
        <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> LogOut</a></li>
     
    </ul>
  </div>

      </ul>
    </div> 
  </div>
</nav>
 
 


</body>
</html>


 
 